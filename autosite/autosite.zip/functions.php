<?php
// no direct access
defined( '_EXEC' ) or die( 'Restricted access' );

// General helper functions

function nl2p($string, $line_breaks = true, $xml = true) {

	$string = str_replace(array('<p>', '</p>', '<br>', '<br />'), '', $string);
	
	// It is conceivable that people might still want single line-breaks
	// without breaking into a new paragraph.
	if ($line_breaks == true)
		return '<p>'.preg_replace(array("/([\n]{2,})/i", "/([^>])\n([^<])/i"), array("</p>\n<p>", '$1<br'.($xml == true ? ' /' : '').'>$2'), trim($string)).'</p>';
	else 
		return '<p>'.preg_replace(
		array("/([\n]{2,})/i", "/([\r\n]{3,})/i","/([^>])\n([^<])/i"),
		array("</p>\n<p>", "</p>\n<p>", '$1<br'.($xml == true ? ' /' : '').'>$2'),
	
		trim($string)).'</p>'; 
}

function autocontact_get_areas() {
	
	$areas = array();
	//$update = false;
	$update = true;
	
	// caching of areas
	$areasfile = "areas.txt";
	if(file_exists($areasfile)) {
		// Check last update of file
		$lastmod = time() - filemtime($areasfile);
		$minchange = 60 *60 * 24;
		if($lastmod > $minchange) {
			$update = true;
		}
		// Get from file
		$areadata = file_get_contents($areasfile);
		$tmpareas = unserialize($areadata);
		if(is_array($tmpareas)&&count($tmpareas)>0) {
			$areas = $tmpareas;	
		}
	} 
	
	if(!count($areas)>0||$update) {
		// Get from external DB
		
		$ctx = stream_context_create(array('http'=>
			array(
				'timeout' => 15,
			)
		));
		
		$area_data = file_get_contents("http://www.megaleads.co.za/services/getareas.php", false, $ctx);
		$mega_areas = json_decode($area_data, true);
		
		if(count($mega_areas)>0) {
				
			$areas = $mega_areas;
			
			// Save to file
			$string_data = serialize($areas);
			file_put_contents("areas.txt", $string_data);
			
		}

	}
	
	return $areas;
		
}



?>