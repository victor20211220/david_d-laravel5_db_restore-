<?php
// no direct access
defined( '_EXEC' ) or die( 'Restricted access' );

@set_magic_quotes_runtime( 0 );

// Start session
if( !isset($_SESSION) ) { session_start(); }


// System includes
require_once( PATH_CONFIGURATION );
require_once( PATH_INCLUDES . DS . 'functions.php' );
require_once( PATH_INCLUDES . DS . 'email' . DS . 'class.phpmailer.php' );

// System configuration
global $CONFIG;
$CONFIG = new Config();

if (@$CONFIG->error_reporting === 0) {
	error_reporting( 0 );
} else if (@$CONFIG->error_reporting > 0) {
	error_reporting(E_ALL & ~E_NOTICE);
	ini_set('display_errors', '1');
}

define('EXT', $CONFIG->ext);
define('SS', $CONFIG->sessionprefix);

// Debugging option: only for development
//global $DEBUG;
//$DEBUG = (isset($CONFIG->debug)?$CONFIG->livesite:false);


$root = $CONFIG->livesite;
if($root == "") {
	if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    $root = $protocol . "://" . $_SERVER['SERVER_NAME'];
}

define('ROOT', $root);

// Database 
global $DB; 
$DB = new mysqli( $CONFIG->host, $CONFIG->user, $CONFIG->pass, $CONFIG->db );
if ($DB->connect_errno)
	die( 'Restricted access' );
	

// Routing: Default to home page
global $PAGE;
$PAGE = array(
	'type' => 'page',
	'index' => 'home',
	'subindex' => ''
);

if(isset($_SERVER['REQUEST_URI'])) {
	$uri =	$_SERVER['REQUEST_URI'];
	
	$uriparts = array_filter(explode('/', $uri));
	
	if($CONFIG->debug) {
		array_shift($uriparts);
	}
	
	if(count($uriparts)>0) {
		$identifier = array_pop($uriparts);	
		
		if(strpos($identifier,'.xml')!==false) {
			$PAGE['index'] = $identifier;
			$PAGE['type'] = 'sitemap';
			require_once('sitemap.php');
			exit;	
		}
		
		switch($identifier) {
			case 'about-us': $PAGE['index'] = 'about-us'; break;
			case 'contact-us': $PAGE['index'] = 'contact-us'; break;
			case 'services': $PAGE['index'] = 'services'; break;
			case 'areas': $PAGE['index'] = 'areas'; break;
			case 'advertise': $PAGE['index'] = 'advertise'; break;
			default: $PAGE['type'] = 'article';
		}
		
		if(count($uriparts)>0 && $PAGE['type'] == 'article') {
			$PAGE['subindex'] = $identifier;
			$PAGE['index'] = array_pop($uriparts);
		}
		
	}
	
}


?>
