<?php
// no direct access
defined( '_EXEC' ) or die( 'Restricted access' );

// General helper functions

function nl2p($string, $line_breaks = true, $xml = true) {

	$string = str_replace(array('<p>', '</p>', '<br>', '<br />'), '', $string);
	
	// It is conceivable that people might still want single line-breaks
	// without breaking into a new paragraph.
	if ($line_breaks == true)
		return '<p>'.preg_replace(array("/([\n]{2,})/i", "/([^>])\n([^<])/i"), array("</p>\n<p>", '$1<br'.($xml == true ? ' /' : '').'>$2'), trim($string)).'</p>';
	else 
		return '<p>'.preg_replace(
		array("/([\n]{2,})/i", "/([\r\n]{3,})/i","/([^>])\n([^<])/i"),
		array("</p>\n<p>", "</p>\n<p>", '$1<br'.($xml == true ? ' /' : '').'>$2'),
	
		trim($string)).'</p>'; 
}

function autocontact_get_areas() {
	
	$areas = array();
	$update = false;
	
	// caching of areas
	$areasfile = "areas.txt";
	if(file_exists($areasfile)) {
		// Check last update of file
		$lastmod = time() - filemtime($areasfile);
		$minchange = 60 *60 * 24;
		if($lastmod > $minchange) {
			$update = true;
		}
		// Get from file
		$areadata = file_get_contents($areasfile);
		$tmpareas = unserialize($areadata);
		if(is_array($tmpareas)&&count($tmpareas)>0) {
			$areas = $tmpareas;	
		}
	} 
	
	if(!count($areas)>0||$update) {
		// Get from external DB
		$DB = new mysqli( 'sql10.jnb1.host-h.net', 'megaluevtu_1_r', 'tx49BXb8', 'megaluevtu_db1' );
		if ($DB->connect_errno) return false;
		
		$qry = '
			SELECT * 
			FROM `ml_provinces` 
			ORDER BY `name` ASC
		';
		$provinces_rs = $DB->query($qry);
		
		if($provinces_rs->num_rows > 0) {
					
			$tmpareas = array();
			
			while($province = $provinces_rs->fetch_assoc()) {
				
				$qry = '
					SELECT * 
					FROM `ml_areas` 
					WHERE parent = 0 
					AND `province_id` = '.$province['id'].' 
					ORDER BY name ASC
				';
				$result = $DB->query($qry);
				
				if($result->num_rows > 0) {
					
					$subareas = array();
					
					while($subareas[] = $result->fetch_assoc()) {}
					
					if(count($subareas) > 0) {
						$tmpareas[] = array($province, $subareas);
					}
										
				}
				
			}
			
			
			if(count($tmpareas)>0) {
				
				$areas = $tmpareas;
				
				// Save to file
				$string_data = serialize($areas);
				file_put_contents("areas.txt", $string_data);
				
			}
		}
	}
	
	return $areas;
		
}



?>