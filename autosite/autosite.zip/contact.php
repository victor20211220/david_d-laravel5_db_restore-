<?php

$data = array();
$errors = array();

if(isset($_POST['contact-submit'])) {
	
	$data = $_POST;
	
	foreach($data as $key=>$val) { 
		$data[$key] = htmlentities(trim($val)); 
	}
	
	if(empty($data['name'])||$data['name']=="") {
		$errors[] = 'Please enter your name';
	}
	if(empty($data['email'])||$data['email']=="") {
		$errors[] = 'Please enter your email address';
	}
	if(filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false) {
		$errors[] = 'Please enter a valid email address';
	}
	if(empty($data['tel'])||$data['tel']=="") {
		$errors[] = 'Please enter your telephone number';
	}
	if(empty($data['area'])||$data['area']=="") {
		$errors[] = 'Please select your area';
	}
	if(empty($data['message'])||$data['message']=="") {
		$errors[] = 'Please enter your message';
	}
	
	if(empty($errors)) {
	
		// All good send the message
		$message = "QryName: ".$data['name']."\r\n";
		$message .= "QryEmail: ".$data['email']."\r\n";
		$message .= "QryTel: ".$data['tel']."\r\n";
		$message .= "QryBody: ".$data['message']."\r\n";
		$message .= "QryCategory: ".$data['category']."\r\n";
		$message .= "QryArea: ".$data['area']."\r\n";
		$message .= "QrySrc: ".$_SERVER['SERVER_NAME']."\r\n";
		
		$mail = new PHPMailer();
	
		if( $CONFIG->mailer == 'smtp' ) {
			$mail->IsSMTP();
			$mail->SMTPAuth = true; 
			$mail->Host = $CONFIG->smtphost;
			$mail->Port = $CONFIG->smtpport; 
			$mail->Username = $CONFIG->smtpuser;
			$mail->Password = $CONFIG->smtppass;
		}
		
		$mail->SetFrom('webmaster@'.$_SERVER['SERVER_NAME'], $CONFIG->site_title);
		$mail->AddAddress("daviddytch@gmail.com");
		$mail->AddAddress("leads@megaleads.co.za");
		$mail->Subject = 'New query submitted from '.$_SERVER['SERVER_NAME'];
		$mail->Body = $message;
		if(!$mail->Send()) {
			$errors[] = 'Sorry, there was a problem while sending the message';
		} else {
			$data = array();
			echo '<div class="successmsg"><strong>Thank you!</strong><br>We have successfully sent your message.</div><br>';
		}
		
	}
}

if(!empty($errors)) {
	echo '
		<div class="errors"><strong>Errors:</strong><br>'.implode('<br>', $errors).'</div><br>
	';
}

?>
	<div id="wpcf7-f26-o1" class="wpcf7">
    
		<div class="screen-reader-response"></div>
		<form novalidate class="wpcf7-form" method="post" target="_self" name="contactForm" id="contactForm">
			<p><span class="wpcf7-form-control-wrap your-name">
				<input type="text" placeholder="Your name" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" size="40" value="<?php echo @$data['name']; ?>" name="name">
				</span> </p>
			<p><span class="wpcf7-form-control-wrap your-email">
				<input type="email" placeholder="Your email" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" size="40" value="<?php echo @$data['email']; ?>" name="email">
				</span> </p>
			<p><span class="wpcf7-form-control-wrap your-tel">
				<input type="text" placeholder="Tel" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" size="40" value="<?php echo @$data['tel']; ?>" name="tel" id="contactTel">
				</span> </p>
			<p><span class="wpcf7-form-control-wrap Area">
				<select class="wpcf7-form-control wpcf7-select" name="area">
					<option value="">-Select area-</option>
					<?php
						$areadata = autocontact_get_areas();
						if(count($areadata)>0) {
							foreach($areadata as $row) {
								$province = $row[0];
								$areas = $row[1];
								echo '<optgroup label="'.$province['name'].'">';
								foreach($areas as $area) {
									if($area['id']>0)
									echo '<option value="'.$area['id'].'" '.(@$data['area']==$area['id']?'selected':'').'>'.$area['name'].'</option>';	
								}
								echo '</optgroup>';
							}
						}
					?>
				</select>
				</span></p>
            <?php 
			$categories = array();
			if($CONFIG->site_categories != "") {
				$categories = unserialize($CONFIG->site_categories);				
			}
			foreach($categories as $catkey=>$catval) {
				$categories[$catkey] = trim($catval);
			}
			asort($categories);
			
			if(count($categories)==1) :
				foreach($categories as $catid=>$catval) {
					echo '<input type="hidden" name="category" value="'.$catid.'" />';
				}
			?>
            <?php else : ?>
            <p><span class="wpcf7-form-control-wrap Area">
            <select class="wpcf7-form-control wpcf7-select" name="category" id="category">
            	<option value="">- Select subject -</option>
				<?php 
                foreach($categories as $catid=>$catval) {
                    echo '<option value="'.$catid.'">'.$catval.'</option>';
                }
                ?>
            </select>
				</span></p>
            <?php endif; ?>
			<p><span class="wpcf7-form-control-wrap your-message">
				<textarea placeholder="Details..." aria-invalid="false" class="wpcf7-form-control wpcf7-textarea" rows="5" cols="40" name="message"><?php echo @$data['message']; ?></textarea>
				</span> </p>
			<p>
				<input type="submit" name="contact-submit" class="wpcf7-form-control wpcf7-submit" value="Send">
			</p>
			<div class="wpcf7-response-output wpcf7-display-none"></div>
		</form>
        
	</div>
