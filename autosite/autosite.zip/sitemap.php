<?php

header('Content-type: text/xml');
header('Pragma: public');
header('Cache-control: private');
header('Expires: -1');

echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<?xml-stylesheet type="text/xsl" href="'.ROOT.'/main-sitemap.xsl"?>';

$sitemap = str_replace('.xml', '', $PAGE['index']);

$lastmod = date('Y-m-d\TH:m:s', filemtime('index.php')).'+00:00';

if($sitemap=='sitemap_index') {
	
	echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
	
	$qry = 'SELECT COUNT(*) `articleCnt` FROM `'.EXT.'articles`';
	$result = $DB->query($qry);
	if($result->num_rows>0) {
		$data = $result->fetch_assoc();
		$totalPages = intval($data['articleCnt']);
		
		for($i=1; $i<=$totalPages; $i++) {
			echo '
				<sitemap>
				<loc>'.ROOT.'/sitemap_page'.$i.'.xml</loc>
				<lastmod>'.$lastmod.'</lastmod>
				</sitemap>
			';	
		}
		
	}
	
	echo '</sitemapindex>';
	
} else {

	$smpage = intval(str_replace('sitemap_page', '', $sitemap));	
	if($smpage > 0) {
		
		// Get article
		$qry = 'SELECT `slug` FROM `'.EXT.'articles` LIMIT '.($smpage-1).', 1';
		$article_rs = $DB->query($qry);
		
		if($article_rs->num_rows > 0) {
		
			$article = $article_rs->fetch_assoc();
			
			
			// Get areas
			$qry = 'SELECT `slug` FROM `'.EXT.'areas` ORDER BY `name` ASC';
			$area_rs = $DB->query($qry);
			if($area_rs->num_rows > 0) {
				
				echo '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
				
				$rowcount = 0;
				
				while($area = $area_rs->fetch_assoc()) {
					echo '
						<url>
							<loc>'.ROOT.'/'.$article['slug'].'/'.$area['slug'].'</loc>
							<lastmod>'.$lastmod.'</lastmod>
							<changefreq>monthly</changefreq>
							<priority>'.(++$rowcount==1?'1.0':'0.6').'</priority>
						</url>
					';
				}
				
				echo '</urlset>';
			}
		}
		
	}
}

?>