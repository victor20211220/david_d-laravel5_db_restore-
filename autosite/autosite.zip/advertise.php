<?php

$data = array();
$errors = array();

if(isset($_POST['advertise-submit'])) {
	
	$data = $_POST;
	
	foreach($data as $key=>$val) { 
		$data[$key] = htmlentities(trim($val)); 
	}
	
	if(empty($data['adv_name'])||$data['adv_name']=="") {
		$errors[] = 'Please enter your name';
	}
	if(empty($data['adv_email'])||$data['adv_email']=="") {
		$errors[] = 'Please enter your email address';
	}
	if(filter_var($data['adv_email'], FILTER_VALIDATE_EMAIL) === false) {
		$errors[] = 'Please enter a valid email address';
	}
	if(empty($data['adv_tel'])||$data['adv_tel']=="") {
		$errors[] = 'Please enter your telephone number';
	}
	if(empty($data['adv_message'])||$data['adv_message']=="") {
		$errors[] = 'Please enter your message';
	}
	
	if(empty($errors)) {
	
		// All good send the message
		$message = "The following advertising query has been submitted:\r\n\r\n";
		$message .= "Name: ".$data['adv_name']."\r\n";
		$message .= "Email: ".$data['adv_email']."\r\n";
		$message .= "Tel: ".$data['adv_tel']."\r\n";
		$message .= "Message: ".$data['adv_message']."\r\n";
		$message .= "Website: ".$_SERVER['SERVER_NAME']."\r\n";
		
		$mail = new PHPMailer();
	
		if( $CONFIG->mailer == 'smtp' ) {
			$mail->IsSMTP();
			$mail->SMTPAuth = true; 
			$mail->Host = $CONFIG->smtphost;
			$mail->Port = $CONFIG->smtpport; 
			$mail->Username = $CONFIG->smtpuser;
			$mail->Password = $CONFIG->smtppass;
		}
		
		$mail->SetFrom('webmaster@'.$_SERVER['SERVER_NAME'], $CONFIG->site_title);
		$mail->AddAddress("info@megaleads.co.za");
		$mail->Subject = 'New advertising query submitted from '.$_SERVER['SERVER_NAME'];
		$mail->Body = $message;
		if(!$mail->Send()) {
			$errors[] = 'Sorry, there was a problem while sending the message';
		} else {
			$data = array();
			echo '<div class="successmsg"><strong>Thank you!</strong><br>We have successfully sent your message.</div><br>';
		}
		
	}
}

if(!empty($errors)) {
	echo '
		<div class="errors"><strong>Errors:</strong><br>'.implode('<br>', $errors).'</div><br>
	';
}

?>
	<div id="wpcf7-f26-o1" class="wpcf7">
    
		<div class="screen-reader-response"></div>
		<form novalidate class="wpcf7-form" method="post" target="_self" name="contactForm" id="contactForm">
			<p><span class="wpcf7-form-control-wrap your-name">
				<input type="text" placeholder="Your name" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" size="40" value="<?php echo @$data['adv_name']; ?>" name="adv_name">
				</span> </p>
			<p><span class="wpcf7-form-control-wrap your-email">
				<input type="email" placeholder="Your email" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" size="40" value="<?php echo @$data['adv_email']; ?>" name="adv_email">
				</span> </p>
			<p><span class="wpcf7-form-control-wrap your-tel">
				<input type="text" placeholder="Tel" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" size="40" value="<?php echo @$data['adv_tel']; ?>" name="adv_tel" id="contactTel">
				</span> </p>
			
            
			<p><span class="wpcf7-form-control-wrap your-message">
				<textarea placeholder="Details..." aria-invalid="false" class="wpcf7-form-control wpcf7-textarea" rows="5" cols="40" name="adv_message"><?php echo @$data['adv_message']; ?></textarea>
				</span> </p>
			<p>
				<input type="submit" name="advertise-submit" class="wpcf7-form-control wpcf7-submit" value="Send">
			</p>
			<div class="wpcf7-response-output wpcf7-display-none"></div>
		</form>
        
	</div>
