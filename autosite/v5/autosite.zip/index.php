<?php define( '_EXEC', 1 ); ?>
<?php require_once('includes.php');  

// Build up the page content
$content = array(
	'heading' => "",
	'body' => ""
);

$meta = array(
	'focuskw' => $CONFIG->site_title.' - '.$CONFIG->site_tel,
	'seo_title' => $CONFIG->site_title.' - '.$CONFIG->site_tel,
	'seo_desc' => 'Call ' .$CONFIG->site_title .' now on '. $CONFIG->site_tel . ' for a free quote',
	'keywords' => ""
);

if(strlen($CONFIG->site_tel2)>1) :
	$meta['seo_title'] .= ' / '.$CONFIG->site_tel2;
endif; 

$article_areas = [];
// Get the areas
$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
$areas_rs = $DB->query($qry);
if($areas_rs->num_rows > 0) {
	
	while($area = $areas_rs->fetch_assoc()) {
		$article_areas[] = $area['name'];
		
	}				
}

//var_dump($PAGE);

if($PAGE['type']=='article' && $PAGE['index']=='services') {

	// Get article
	$qry = 'SELECT * FROM `'.EXT.'articles` WHERE `slug` = "'.$PAGE['subindex'].'" ';
	$article_rs = $DB->query($qry);
	if($article_rs->num_rows > 0) {
		$article = $article_rs->fetch_assoc();
		
		$body = $article['article_content'];
		$body = str_replace('{KEYWORD}', $CONFIG->site_place, $body);
		
		$shorttitle = $article['article_title'];
		
		$title = str_replace($CONFIG->site_place, '{KEYWORD}',$article['article_title']);
		if(strpos($title, '{KEYWORD}')===false) {
			$title .= ' {KEYWORD}';	
		}
		
		$content['heading'] = str_replace('{KEYWORD}', $CONFIG->site_place, $title);
		
		$content['body'] = '
			<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>'.
			$body.
			'<p>We are the best '.$shorttitle.' company in '.$CONFIG->site_place.
				' so give us a call at: '.$CONFIG->site_tel.' today!</p>';
		/*		
		$content['body'] .= "<h3>Areas that we operate in:</h3>";		
		$content['body'] .= implode(', ', $article_areas);		
		*/
		$meta['focuskw'] = $content['heading'].' - '.$CONFIG->site_tel;
		$meta['seo_title'] = $content['heading'].' - '.$CONFIG->site_tel;
		
		if(strlen($CONFIG->site_tel2)>1) :
			$meta['seo_title'] .= ' / '.$CONFIG->site_tel2;
		endif; 
		
		$meta['seo_desc'] = 'Call ' .$content['heading'] .' now on '. $CONFIG->site_tel . ' for a free quote';
		$meta['keywords'] = $article['article_adwords'];
			
	}
	
}

if($PAGE['type']=='article' && $PAGE['index']=='areas') {
	
	// Get area
	$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `slug` = "'.$PAGE['subindex'].'"';
	$area_rs = $DB->query($qry);
	if($area_rs->num_rows > 0) {
		$area = $area_rs->fetch_assoc();
	}

	// Get article
	$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 1';
	$article_rs = $DB->query($qry);
	if($article_rs->num_rows > 0) {
		$article = $article_rs->fetch_assoc();
		
		$body = $article['article_content'];
		$body = str_replace('{KEYWORD}', $area['name'], $body);
		
		$shorttitle = $article['article_title'];
		
		$title = str_replace($CONFIG->site_place, '{KEYWORD}',$article['article_title']);
		if(strpos($title, '{KEYWORD}')===false) {
			$title .= ' {KEYWORD}';	
		}
		
		$content['heading'] = str_replace('{KEYWORD}', $area['name'], $title);
		
		$content['body'] = '
			<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>'.
			$body.
			'<p>We are the best '.$shorttitle.' company in '.$area['name'].
				' so give us a call at: '.$CONFIG->site_tel.' today!</p>';	
		/*
		$minid = $area['id'];
		$maxid = 0;
		
		$qry = '
			SELECT `id` 
			FROM `'.EXT.'areas` 
			WHERE `id` > '.$minid.'
			AND `menu` = 1 
			ORDER BY `id` ASC
		';
		$max_rs = $DB->query($qry);
		if($max_rs->num_rows > 0) {
			$maxrow = $max_rs->fetch_assoc();
			$maxid = $maxrow['id'];
		}
		
		if($maxid > 0) {
			
			$qry = '
				SELECT * 
				FROM `'.EXT.'areas` 
				WHERE `id` BETWEEN '.$minid.' AND '.$maxid.' 
				AND `menu` <> 1
			';
			$other_areas = $DB->query($qry);
			if($other_areas->num_rows > 0) {
				$content['body'] .= "<h3>Other areas that we service in ".$area['name'].":</h3>";	
				while($otherarea = $other_areas->fetch_assoc()) {
					$content['body'] .= "* ".$otherarea['name']." ";	
				}
			}
		}
		*/
		$meta['focuskw'] = $content['heading'].' - '.$CONFIG->site_tel;
		$meta['seo_title'] = $content['heading'].' - '.$CONFIG->site_tel;
		if(strlen($CONFIG->site_tel2)>1) :
			$meta['seo_title'] .= ' / '.$CONFIG->site_tel2;
		endif; 
		$meta['seo_desc'] = 'Call ' .$content['heading'] .' now on '. $CONFIG->site_tel . ' for a free quote';
		$meta['keywords'] = $article['article_adwords'];
			
	}

}

if($PAGE['type']=='article' && ($PAGE['index']!='areas'&&$PAGE['index']!='services')) {
	
	// Get area
	$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `slug` = "'.$PAGE['subindex'].'"';
	$area_rs = $DB->query($qry);
	if($area_rs->num_rows > 0) {
		$area = $area_rs->fetch_assoc();
	}

	// Get article
	$qry = 'SELECT * FROM `'.EXT.'articles` WHERE `slug` = "'.$PAGE['index'].'"';
	$article_rs = $DB->query($qry);
	if($article_rs->num_rows > 0) {
		$article = $article_rs->fetch_assoc();
		
		$body = $article['article_content'];
		$body = str_replace('{KEYWORD}', $area['name'], $body);
		
		$shorttitle = $article['article_title'];
		
		$title = str_replace($CONFIG->site_place, '{KEYWORD}',$article['article_title']);
		if(strpos($title, '{KEYWORD}')===false) {
			$title .= ' {KEYWORD}';	
		}
		
		$content['heading'] = str_replace('{KEYWORD}', $area['name'], $title);
		
		$content['body'] = '
			<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>'.
			$body.
			'<p>We are the best '.$shorttitle.' company in '.$area['name'].
				' so give us a call at: '.$CONFIG->site_tel.' today!</p>';	

		
		$meta['focuskw'] = $content['heading'].' - '.$CONFIG->site_tel;
		$meta['seo_title'] = $content['heading'].' - '.$CONFIG->site_tel;
		if(strlen($CONFIG->site_tel2)>1) :
			$meta['seo_title'] .= ' / '.$CONFIG->site_tel2;
		endif; 
		$meta['seo_desc'] = 'Call ' .$content['heading'] .' now on '. $CONFIG->site_tel . ' for a free quote';
		$meta['keywords'] = $article['article_adwords'];
			
	}

}


if($PAGE['type']=='page') {
if($PAGE['index']=='home') {
	// Get article
	$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 1';
	$article_rs = $DB->query($qry);
	if($article_rs->num_rows > 0) {
		$article = $article_rs->fetch_assoc();
		
		$body = $article['article_content'];
		$shorttitle = str_replace($CONFIG->site_place, '',$article['article_title']);
		//$body = str_replace('{KEYWORD}', '', $body);
		$body = str_replace('{KEYWORD}', $CONFIG->site_place, $body);
		
		$content['heading'] = $CONFIG->site_title;
		
		$content['body'] = '
			<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>
			<p>If you are looking for '.$CONFIG->site_title.' we can assist with the following services:</p>'.
			$body.
			'<p>We are the best '.$shorttitle.' company in '.$CONFIG->site_place.
				' so give us a call at: '.$CONFIG->site_tel.' today!</p>';

		
		$meta['focuskw'] = $content['heading'].' - '.$CONFIG->site_tel;
		$meta['seo_title'] = $CONFIG->site_title.' - '.$CONFIG->site_tel;
		
		if(strlen($CONFIG->site_tel2)>1) :
			$meta['seo_title'] .= ' / '.$CONFIG->site_tel2;
		endif; 
		
		$meta['seo_desc'] = 'Call ' .$content['heading'] .' now on '. $CONFIG->site_tel . ' for a free quote';
		$meta['keywords'] = $article['article_adwords'];
	}
}
		
	if($PAGE['index']=='about-us') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "about"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "About us";
			$content['body'] = $article['page_content'];
		}
	}
		
	if($PAGE['index']=='services') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "services"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "Services";
			$content['body'] = $article['page_content'];
			
			$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 10';
			$article_rs = $DB->query($qry);
			if($article_rs->num_rows > 0) {
				$content['body'] .= "<h3>Our services:</h3>";
				$content['body'] .= "<ul>";
				while($article = $article_rs->fetch_assoc()) {
					$content['body'] .= '<li><a href="'.ROOT.'/services/'.$article['slug'].'">'.$article['article_title'].'</a></li>';	
				}
				$content['body'] .= "</ul>";
				
			}
		}
	}
		
	if($PAGE['index']=='contact-us') {	
		$content['heading'] = "Contact ".$CONFIG->site_title;
		$content['body'] = '
			<h2>Contact us today for a free quote!</h2>
			<p>
				We service the entire '.$CONFIG->site_place.' area. 
				Please use our contact form to send us your enquiry. <br>
				You can also contact us directly or send an SMS and we will get back to you:
			</p>
			<p>
				<strong>Telephone: </strong>
				<a href="tel:'.$CONFIG->site_tel.'">'.$CONFIG->site_tel.'</a>
				';
			if(strlen($CONFIG->site_tel2)>1) :
						$content['body'] .= ' OR 
						<a href="tel:'.$CONFIG->site_tel2.'">'.$CONFIG->site_tel2.'</a>';
			endif;
		$content['body'] .= '
			</p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7182354.058309485!2d24.672226849999998!3d-28.4792811!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1c34a689d9ee1251%3A0xe85d630c1fa4e8a0!2sSouth+Africa!5e0!3m2!1sen!2sza!4v1435702515289" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		';
	}
		
	if($PAGE['index']=='advertise') {	
		$content['heading'] = "Advertise with us";
		$content['body'] = '
			<p>
				We connect you with clients requesting your services in your area. <br>
				For more information - fill in the query form below or call the following number.
			</p>
			<p>
				<strong>Telephone: </strong>
				'.$CONFIG->site_tel.'
			</p>
		';
	}
			
		
	if($PAGE['index']=='areas') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "areas"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "Areas that we service in ".$CONFIG->site_place;
			$content['body'] = $article['page_content']."
				<h3>Some of the main areas that we service include:</h3>
				<ul>
			";
			// Get the areas
			$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
			$areas_rs = $DB->query($qry);
			if($areas_rs->num_rows > 0) {
				
				while($area = $areas_rs->fetch_assoc()) {
					$content['body'] .= '
						<li>
							<a href="'.ROOT.'/areas/'.$area['slug'].'.html">'.$area['name'].'</a>
						</li>';	
				}
					
			}
			$content['body'] .= "</ul>";
			
		}
	}
	
}


?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo $meta['seo_title']; ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="<?php echo $meta['seo_desc']; ?>">
<meta name="format-detection" content="telephone=no">
<meta name="keywords" content="<?php echo $meta['keywords']; ?>">
<!-- Open graph tags -->
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo $meta['seo_title']; ?>" />
<meta property="og:description" content="<?php echo $meta['seo_desc']; ?>" />
<meta property="og:url" content="http://<?php echo $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>" />
<meta property="og:site_name" content="<?php echo $CONFIG->site_title; ?>" />

<link href="<?php echo ROOT; ?>/css/screen.css" rel="stylesheet" type="text/css">
<link href="<?php echo ROOT; ?>/css/nivo-slider.css" rel="stylesheet" type="text/css">
<script type="application/ld+json">
{
    "@context": "http://schema.org",
    "@type": "LocalBusiness",
    "name": "<?php echo $CONFIG->site_title; ?>",
    "url": "http://<?php echo $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>",
    "telephone": "<?php echo $CONFIG->site_tel; ?>",
    "address": {
        "@type": "PostalAddress",
        "addressRegion": "<?php echo $CONFIG->site_place; ?>",
        "addressCountry": "ZA"
    },
    "openingHours": [
        "Mo-Fr 08:00-18:00",
        "Sa-Su 08:00-17:00"
    ]
}
</script>
</head>

<body class="theme-<?php echo $CONFIG->theme; ?>">

<div id="wrapper">
<div itemscope itemtype="http://schema.org/LocalBusiness">
	<header id="mainheader" class="sitewidth">
		<div class="container">
			<div id="logo"><h1><a href="<?php echo $CONFIG->livesite; ?>" title="<?php echo $CONFIG->site_title; ?>"><?php echo $CONFIG->site_title; ?></a><img itemprop="image" src="<?php echo ROOT; ?>/images/logo.jpg" alt="<?php echo $CONFIG->site_title; ?>" /></h1></div>
			<div id="contacts">
				<span class="tel">
					<a href="tel:<?php echo $CONFIG->site_tel; ?>"><?php echo $CONFIG->site_tel; ?></a> 
					<?php if(strlen($CONFIG->site_tel2)>1) : ?>
					OR 
					<a href="tel:<?php echo $CONFIG->site_tel2; ?>"><?php echo $CONFIG->site_tel2; ?></a>
					<?php endif; ?>
				</span>
				<span class="info">
					<span class="heading">CALL, SMS OR EMAIL!</span>
					<span class="hours">
						<?php echo $CONFIG->site_header; ?>
					</span>
				</span>
			</div>
			<div class="clr"></div>
		</div>
	</header>
	
	<nav id="mainnav" class="sitewidth">
		<div class="container">
			<a href="#" class="menu-toggle">
				<span class="btn"></span>
				<span class="txt">Toggle navigation</span>
			</a>
			<ul class="mainmenu">
				<li class="<?php echo ($PAGE['index']=='home'?'active':''); ?>"><a href="<?php echo ROOT; ?>">Home</a></li>
				<li class="submenu" <?php echo ($PAGE['index']=='areas'?'active':''); ?>><a href="<?php echo ROOT; ?>/areas.html">Areas</a>
					<ul>
						<?php 

							// Get the areas
							$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
							$areas_rs = $DB->query($qry);
							if($areas_rs->num_rows > 0) {
								
								while($area = $areas_rs->fetch_assoc()) {
									echo '
										<li>
											<a href="'.ROOT.'/areas/'.$area['slug'].'.html">'.$area['name'].'</a>
										</li>';	
								}
									
							}
						
						?>
					</ul>
				</li>
				<li class="submenu" <?php echo ($PAGE['index']=='services'?'active':''); ?>><a href="<?php echo ROOT; ?>/services.html">Services</a>
					<ul>
						<?php 
						
							// Get the main articles
							$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 10';
							$article_rs = $DB->query($qry);
							if($article_rs->num_rows > 0) {
							
								while($article = $article_rs->fetch_assoc()) {
									echo '<li><a href="'.ROOT.'/services/'.$article['slug'].'.html">'.$article['article_title'].'</a></li>';	
								}
								
							}
							
						?>	
					</ul>
				</li>
				<li class="<?php echo ($PAGE['index']=='about-us'?'active':''); ?>"><a href="<?php echo ROOT; ?>/about-us.html">About Us</a></li>
				<li class="<?php echo ($PAGE['index']=='contact-us'?'active':''); ?>"><a href="<?php echo ROOT; ?>/contact-us.html">Contact Us</a></li>
			</ul>
			<div class="clr"></div>
		</div>
	</nav>
	
	<div id="maincontent" class="sitewidth">
		<div class="container">
			<article id="page">
			<?php if($PAGE['index']=='home'): ?>
				<div id="bannerslider">
					<div class="slider-wrapper">			
						<div id="slider" class="nivoSlider">
						<?php
							$slidespath = 'images/slides/';
							if ($handle = opendir($slidespath)) {
								while (false !== ($entry = readdir($handle))) {
									if ($entry != "." && $entry != "..") {
										echo '<img src="'.ROOT.'/images/slides/'.$entry.'" />';
									}
								}
								closedir($handle);
							}
						?>
						</div>
					</div>
					<div class="clr"></div>
				</div>
				<?php endif; ?>
				<div class="article-content">
					<header class="page-header">
						<h1 class="page-title"><?php echo $content['heading']; ?></h1>
					</header>
					<div style="float:right"><div class="addthis_sharing_toolbox"></div></div>
					<?php echo $content['body']; ?>
					<p>&nbsp;</p>
				</div>
			</article>
			<aside id="sidebar">
				<div id="quote-box" class="widget">
					<h3>Get a free quote now!</h3>
					<div class="quote-form widget-container">
						<?php require_once('contact.php'); ?>
					</div>
				</div>
				<div id="disclaimer" class="widget">
					<div class="widget-container">
						<img src="<?php echo ROOT; ?>/images/terms.jpg" style="max-width:100%" />
					</div>
				</div>
				<div id="services" class="widget">
					<h3>Services we offer</h3>
					<div class="widget-container">
						<ul>
						<?php 
						
							// Get the main articles
							$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 10';
							$article_rs = $DB->query($qry);
							if($article_rs->num_rows > 0) {
							
								while($article = $article_rs->fetch_assoc()) {
									echo '<li><a href="'.ROOT.'/services/'.$article['slug'].'.html">'.$article['article_title'].'</a></li>';	
								}
								
							}
							
						?>	
						</ul>
					</div>
				</div>
			</aside>
			<div class="clr"></div>
		</div>
	</div>
	
	<footer id="mainfooter" class="sitewidth">
		<div class="container">
			<div class="column">
				<h3>Menu</h3>
				<ul>
					<li><a href="<?php echo ROOT; ?>">Home</a></li>
					<li><a href="<?php echo ROOT; ?>/about-us.html">About</a></li>
					<li><a href="<?php echo ROOT; ?>/services.html">Services</a></li>
					<li><a href="<?php echo ROOT; ?>/areas.html">Areas</a></li>
					<li><a href="<?php echo ROOT; ?>/contact-us.html">Contact</a></li>
				</ul>
			</div>
			<div class="column">
				<h3>Contact us</h3>
				<p>
					<strong>Contact us today for a free quote!</strong><br>
					Please use our contact form to send us your enquiry.
					Alternatively you can also contact us directly:<br><br>
					<strong>Telephone:</strong><br><a href="tel:<?php echo $CONFIG->site_tel; ?>"><?php echo $CONFIG->site_tel; ?></a>
					<?php if(strlen($CONFIG->site_tel2)>1) :
						echo ' / <a href="tel:'.$CONFIG->site_tel2.'">'.$CONFIG->site_tel2.'</a>';
					endif; ?>
				</p>
			</div>
			<div class="clr"></div>
		</div>
	</footer>
	<div id="copyright">
		<div class="container">
		</div>
	</div>
</div>
</div><!-- end wrapper -->
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="<?php echo ROOT; ?>/js/html5shiv.js"></script>
  <script src="<?php echo ROOT; ?>/js/respond.js"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo ROOT; ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo ROOT; ?>/js/jquery-migrate.min.js"></script>
<script type="text/javascript" src="<?php echo ROOT; ?>/js/jquery.nivo.slider.pack.js"></script>	
<script type="text/javascript" src="<?php echo ROOT; ?>/js/jquery.maskedinput.js"></script>	
<script type="text/javascript" src="<?php echo ROOT; ?>/js/jquery.validate.min.js"></script>	
<script type="text/javascript" language="javascript">
jQuery(document).ready(function($) {
	
	// Menu toggle
	$('.menu-toggle').click(function(e) {
		e.preventDefault();
		$('ul.mainmenu').slideToggle('fast');
	});
	
	$('ul.mainmenu li:has(> ul) >a').click(function(e) {
		e.preventDefault();
		var $el = $(this).parent();
		if(!$el.hasClass('opened')) {
			$('ul.mainmenu li.opened').removeClass('opened').find('ul').hide();
		}
		$el.toggleClass('opened').find('ul').slideToggle('fast');
	});
	
    $('#slider').nivoSlider({
		effect: 'fade',
        directionNav: false, // Next & Prev navigation
        controlNav: true, // Next & Prev navigation
		controlNavThumbs: false, 
        pauseTime: 5000
    });
	
	$("#tel").mask("999 999 9999");
	
	$('#quoteform').validate({
		rules: {
			name: "required",
			email: {
				required: true,
				email: true
			},
			tel: "required",
			area: "required",
			message: "required"
		},
		messages: {
			name: "Please enter your name",
			email: {
				required: "Please enter your email address",
				email: "Please enter a valid email address"
			},
			tel: "Please enter your telephone",
			area: "Please select your area",
			message: "Please enter your message"
		}
	});

});

</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-506e7a5c5672f1aa"></script>
</body>
</html>
