<?php

class Config {
	
	// Database config
	var $host = '{MYSQL_HOST}';
	var $user = '{MYSQL_USER}';
	var $pass = '{MYSQL_PASS}';
	var $db = '{MYSQL_DB}';
	var $ext = 'at_';
	
	// Site settings
	var $site_title = '{SITE_TITLE}';
	var $site_place = '{SITE_PLACE}';
	var $site_tel = '{SITE_TEL}';
	var $site_tel2 = '{SITE_TEL2}';
	var $site_categories = '{SITE_CATEGORIES}';
	var $livesite = '{SITE_URL}';
	
	var $update_path = 'http://synapselabs.co.za/autosite/';
	
	// Admin folder
	var $admindir = 'admin';
	
	// Sessions
	var $sessionprefix = 'ss_';
	
	// Email
	var $mailfrom = 'webmaster@megaleads.co.za';
	var $fromname = 'MegaLeads';
	var $mailer = 'mail'; // Either mail or smtp
	var $smtphost = 'smtp.domain.co.za'; // SMTP Server
	var $smtpport = '25'; // SMTP Server port
	var $smtpuser = 'webmaster@domain.co.za'; // SMTP Server username
	var $smtppass = ''; // SMTP Server password
	
	// Environment
	var $error_reporting = '1';
	
	// Secret key
	var $secret = 'a9xTvW';
	
	// Debugging option
	var $debug = false;
	
	// Colour theme
	var $theme = '{SITE_THEME}';


}

?>