<?php

header('Content-type: text/xml');
header('Pragma: public');
header('Cache-control: private');
header('Expires: -1');

echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<?xml-stylesheet type="text/xsl" href="'.ROOT.'/main-sitemap.xsl"?>';

$sitemap = str_replace('.xml', '', $PAGE['index']);

$lastmod = date('Y-m-d\TH:m:s', filemtime('index.php')).'+00:00';

?>
<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<url>
	<loc><?php echo ROOT; ?></loc>
	<lastmod><?php echo $lastmod; ?></lastmod>
	<changefreq>monthly</changefreq>
	<priority>1.0</priority>
</url>
<url>
	<loc><?php echo ROOT; ?>/areas.html</loc>
	<lastmod><?php echo $lastmod; ?></lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.6</priority>
</url>
<url>
	<loc><?php echo ROOT; ?>/services.html</loc>
	<lastmod><?php echo $lastmod; ?></lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.6</priority>
</url>
<url>
	<loc><?php echo ROOT; ?>/about-us.html</loc>
	<lastmod><?php echo $lastmod; ?></lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.6</priority>
</url>
<url>
	<loc><?php echo ROOT; ?>/contact-us.html</loc>
	<lastmod><?php echo $lastmod; ?></lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.6</priority>
</url>
<?php

// Get articles
$qry = 'SELECT `slug` FROM `'.EXT.'articles`';
$article_rs = $DB->query($qry);

if($article_rs->num_rows > 0) {

	if($article_rs->num_rows > 0) {
		
		$rowcount = 0;
		
		while($article = $article_rs->fetch_assoc()) {
			echo '
				<url>
					<loc>'.ROOT.'/services/'.$article['slug'].'.html</loc>
					<lastmod>'.$lastmod.'</lastmod>
					<changefreq>monthly</changefreq>
					<priority>'.(++$rowcount==1?'1.0':'0.6').'</priority>
				</url>
			';
		}
	}
}

// Get the areas
$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
$areas_rs = $DB->query($qry);
if($areas_rs->num_rows > 0) {
		
	$rowcount = 0;
	
	while($area = $areas_rs->fetch_assoc()) {
		echo '
			<url>
				<loc>'.ROOT.'/areas/'.$area['slug'].'.html</loc>
				<lastmod>'.$lastmod.'</lastmod>
				<changefreq>monthly</changefreq>
				<priority>'.(++$rowcount==1?'1.0':'0.6').'</priority>
			</url>
		';
	}
		
}

// Inject all category / areas
// Get article
$qry = 'SELECT `slug` FROM `'.EXT.'articles`';
$article_rs = $DB->query($qry);

$max = 45000;

if($article_rs->num_rows > 0) {

	while($article = $article_rs->fetch_assoc()) {
	
		// Get areas
		$qry = 'SELECT `slug` FROM `'.EXT.'areas` ORDER BY `name` ASC';
		$area_rs = $DB->query($qry);
		if($area_rs->num_rows > 0) {
			
			$rowcount = 0;
			
			while($area = $area_rs->fetch_assoc()) {
				echo '
					<url>
						<loc>'.ROOT.'/page/'.$article['slug'].'/'.$area['slug'].'.html</loc>
						<lastmod>'.$lastmod.'</lastmod>
						<changefreq>monthly</changefreq>
						<priority>'.(++$rowcount==1?'1.0':'0.6').'</priority>
					</url>
				';
				if(--$max <= 0) break;
			}
		}
		if($max <= 0) break;
	}
}

?>
</urlset>