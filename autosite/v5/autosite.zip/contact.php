<?php

$data = array();
$errors = array();

if(isset($_POST['contact-submit'])) {
	
	$data = $_POST;
	
	foreach($data as $key=>$val) { 
		$data[$key] = htmlentities(trim($val)); 
	}
	
	if(empty($data['name'])||$data['name']=="") {
		$errors[] = 'Please enter your name';
	}
	if(empty($data['email'])||$data['email']=="") {
		$errors[] = 'Please enter your email address';
	}
	if(filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false) {
		$errors[] = 'Please enter a valid email address';
	}
	if(empty($data['tel'])||$data['tel']=="") {
		$errors[] = 'Please enter your telephone number';
	}
	if(empty($data['area'])||$data['area']=="") {
		$errors[] = 'Please select your area';
	}
	if(empty($data['message'])||$data['message']=="") {
		$errors[] = 'Please enter your message';
	}
	
	if(empty($errors)) {
	
		// All good send the message
		$message = "QryName: ".$data['name']."\r\n";
		$message .= "QryEmail: ".$data['email']."\r\n";
		$message .= "QryTel: ".$data['tel']."\r\n";
		$message .= "QryBody: ".$data['message']."\r\n";
		$message .= "QryCategory: ".$data['category']."\r\n";
		$message .= "QryArea: ".$data['area']."\r\n";
		$message .= "QrySrc: ".$_SERVER['SERVER_NAME']."\r\n";
		
		$mail = new PHPMailer();
	
		if( $CONFIG->mailer == 'smtp' ) {
			$mail->IsSMTP();
			$mail->SMTPAuth = true; 
			$mail->Host = $CONFIG->smtphost;
			$mail->Port = $CONFIG->smtpport; 
			$mail->Username = $CONFIG->smtpuser;
			$mail->Password = $CONFIG->smtppass;
		}
		
		$mail->SetFrom('webmaster@'.$_SERVER['SERVER_NAME'], $CONFIG->site_title);
		$mail->AddAddress("daviddytch@gmail.com");
		$mail->Subject = 'New query submitted from '.$_SERVER['SERVER_NAME'];
		$mail->Body = $message;
		if(!$mail->Send()) {
			$errors[] = 'Sorry, there was a problem while sending the message';
		} else {
			$data = array();
			echo '<div class="successmsg"><strong>Thank you!</strong><br>We have successfully sent your message.</div><br>';
		}
		
	}
}

if(!empty($errors)) {
	echo '
		<div class="errors"><strong>Errors:</strong><br>'.implode('<br>', $errors).'</div><br>
	';
}

?>
	<form method="post" target="_self" id="quoteform">
	<div class="form-control" id="name-group">
		<label for="name">Your name: <span>*</span></label>
		<input type="text" name="name" id="name" value="<?php echo @$data['name']; ?>" />
	</div>
	<div class="form-control" id="email-group">
		<label for="email">Your email: <span>*</span></label>
		<input type="text" name="email" id="email" value="<?php echo @$data['email']; ?>" />
	</div>
	<div class="form-control" id="tel-group">
		<label for="tel">Telephone: <span>*</span></label>
		<input type="text" name="tel" id="tel" value="<?php echo @$data['tel']; ?>" />
	</div>
	<div class="form-control" id="area-group">
		<label for="area">Area: <span>*</span></label>
		<select name="area">
			<option value="">-Select area-</option>
			<?php
				$areadata = autocontact_get_areas();
				if(count($areadata)>0) {
					foreach($areadata as $row) {
						$province = $row[0];
						$areas = $row[1];
						echo '<optgroup label="'.$province['name'].'">';
						foreach($areas as $area) {
							if($area['id']>0)
							echo '<option value="'.$area['name'].'" '.(@$data['area']==$area['name']?'selected':'').'>'.$area['name'].'</option>';	
						}
						echo '</optgroup>';
					}
				}
			?>
		</select>
	</div>
	<?php 
	$categories = array();
	if($CONFIG->site_categories != "") {
		$categories = unserialize($CONFIG->site_categories);				
	}
	foreach($categories as $catkey=>$catval) {
		$categories[$catkey] = trim($catval);
	}
	asort($categories);
	
	if(count($categories)==1) :
		foreach($categories as $catid=>$catval) {
			echo '<input type="hidden" name="category" value="'.$catval.'" />';
		}
	?>
	<?php else : ?>
	<div class="form-control" id="category-group">
		<label for="category">Subject:</label>
		<select name="category">
			<option value="">- Select subject -</option>
			<?php 
			foreach($categories as $catid=>$catval) {
				echo '<option value="'.$catval.'">'.$catval.'</option>';
			}
			?>
		</select>
	</div>
	<?php endif; ?>
	<div class="form-control" id="message-group">
		<label for="message">Query / request:</label>
		<textarea placeholder="Details..." rows="5" cols="40" name="message"><?php echo @$data['message']; ?></textarea>
	</div>
	<div class="submit">
		<input type="submit" name="contact-submit" value="Send message" />
	</div>
	</form>
