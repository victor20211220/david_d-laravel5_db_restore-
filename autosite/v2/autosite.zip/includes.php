<?php

// no direct access
defined( '_EXEC' ) or die( 'Restricted access' );

define('PATH_BASE', dirname(__FILE__) );

define( 'DS', DIRECTORY_SEPARATOR );

//Global definitions
$parts = explode( DS, PATH_BASE );

//Defines
define( 'PATH_ROOT', implode( DS, $parts ) );

define( 'PATH_SITE', PATH_ROOT );
define( 'PATH_CONFIGURATION', PATH_ROOT.DS.'config.php' );
define( 'PATH_INCLUDES', PATH_ROOT.DS.'includes' );

require_once ( PATH_BASE .DS.'includes'.DS.'framework.php' );

// Update check

$update = "";
$getupdate = true;
if(file_exists('update.txt')) {
	$update = file_get_contents('update.txt');
	$update_date = strtotime($update);
	if( date('Y-m-d', $update_date) == date('Y-m-d') ) {
		$getupdate = false;	
	}
}

// Run the update
if($getupdate) {
	$file = fopen("update.txt","w");
	fwrite($file,date('Y-m-d H:i:s'));
	fclose($file);
	
	// Get site settings
	$path = 'http://www.megaleads.co.za/services/siteinfo.php?url='.$CONFIG->livesite;
	
	$ctx = stream_context_create(array('http'=>
		array(
			'timeout' => 15,
		)
	));
	
	$data = file_get_contents($path, false, $ctx);
	$siteinfo = json_decode($data, true);
	
	$settings = array(
		'title'=>$CONFIG->site_title,
		'place'=>$CONFIG->site_place,
		'tel'=>$CONFIG->site_tel,
		'tel2'=>$CONFIG->site_tel2,
		'categories'=>$CONFIG->site_categories,
		'header'=>"",
		'disclaimer'=>""
	);
	
	if(is_array($siteinfo)) {
		foreach($settings as $k=>$v) {
			if(isset($siteinfo[$k]) && strlen($siteinfo[$k])>0) {
				$settings[$k] = $siteinfo[$k];	
			}
		}
	}
	file_put_contents('settings.json', json_encode($settings, true));
}

// Read settings file and override CONFIG
$CONFIG->site_header = "Monday-Friday: 8am-6pm<br>Sat, Sunday, Public Holidays: 8am-5pm";
$CONFIG->disclaimer = '<p><strong>Please note this is a quoting system where we put you in touch with contractors in your area. We do not employ or are affiliated to the contractors. </strong><br>
<small style="color:#666;">* When referred, you deal directly with that service provider. We do not get involved in pricing, nor guarantees of services or products. We cannot be held liable for any loss, claim or damage whatsoever.</small>
</p><p><a href="http://www.websiteterms.co.za/" target="_blank">Terms and conditions</a></p>';

if(file_exists('settings.json')) {
	$settings = json_decode(file_get_contents('settings.json'), true);
	if(is_array($settings)) {
		if(strlen($settings['title'])>0) $CONFIG->site_title = $settings['title'];
		if(strlen($settings['place'])>0) $CONFIG->site_place = $settings['place'];
		if(strlen($settings['tel'])>0) $CONFIG->site_tel = $settings['tel'];
		if(strlen($settings['tel2'])>0) $CONFIG->site_tel2 = $settings['tel2'];
		if(strlen($settings['categories'])>0) $CONFIG->site_categories = $settings['categories'];
		if(strlen($settings['header'])>0) $CONFIG->site_header = $settings['header'];
		if(strlen($settings['disclaimer'])>0) $CONFIG->disclaimer = $settings['disclaimer'];
	}
}