<?php

// no direct access
defined( '_EXEC' ) or die( 'Restricted access' );


//Global definitions
$parts = explode( DS, PATH_BASE );

$root = "http://localhost/MegaLeadz/";

//Defines
define( 'ROOT', $root );
define( 'PATH_ROOT', implode( DS, $parts ) );

define( 'PATH_SITE', PATH_ROOT );
define( 'PATH_CONFIGURATION', PATH_ROOT );
define( 'PATH_ADMINISTRATOR', PATH_ROOT.DS.'controlpanel' );
define( 'PATH_INCLUDES', PATH_ROOT.DS.'includes' );

