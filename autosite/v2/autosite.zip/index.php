<?php define( '_EXEC', 1 ); ?>
<?php require_once('includes.php'); 

// Build up the page content
$content = array(
	'heading' => "",
	'body' => ""
);

$meta = array(
	'focuskw' => $CONFIG->site_title.' - '.$CONFIG->site_tel,
	'seo_title' => $CONFIG->site_title.' - '.$CONFIG->site_tel,
	'seo_desc' => 'Call ' .$CONFIG->site_title .' now on '. $CONFIG->site_tel . ' for a free quote'
);

$article_areas = [];
// Get the areas
$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
$areas_rs = $DB->query($qry);
if($areas_rs->num_rows > 0) {
	
	while($area = $areas_rs->fetch_assoc()) {
		$article_areas[] = $area['name'];
		
	}				
}

if($PAGE['type']=='article') {

	// Get article
	$qry = 'SELECT * FROM `'.EXT.'articles` WHERE `slug` = "'.$PAGE['index'].'" ';
	$article_rs = $DB->query($qry);
	if($article_rs->num_rows > 0) {
		$article = $article_rs->fetch_assoc();
		
		$body = $article['article_content'];
		//$body = str_replace($CONFIG->site_place, '',$body);
		$body = str_replace('{KEYWORD}', $CONFIG->site_place, $body);
		
		$shorttitle = $article['article_title'];
		
		$title = str_replace($CONFIG->site_place, '{KEYWORD}',$article['article_title']);
		if(strpos($title, '{KEYWORD}')===false) {
			$title .= ' {KEYWORD}';	
		}
		
		$content['heading'] = str_replace('{KEYWORD}', $CONFIG->site_place, $title);
		
		$content['body'] = '
			<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>
			<p>If you are looking for '.$content['heading'].' we can assist with the following services:</p>'.
			$body.
			'<p>We are the best '.$shorttitle.' company in '.$CONFIG->site_place.
				' so give us a call at: '.$CONFIG->site_tel.' today!</p>';
				
		$content['body'] .= "<h3>Areas that we operate in:</h3>";		
		$content['body'] .= implode(', ', $article_areas);		
		
		$meta['focuskw'] = $content['heading'].' - '.$CONFIG->site_tel;
		$meta['seo_title'] = $content['heading'].' - '.$CONFIG->site_tel . ' - '.$CONFIG->site_title;
		$meta['seo_desc'] = 'Call ' .$content['heading'] .' now on '. $CONFIG->site_tel . ' for a free quote';
			
	}
	
}


if($PAGE['type']=='page') {
	if($PAGE['index']=='home') {
		// Get article
		$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 1';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$body = $article['article_content'];
			$shorttitle = str_replace($CONFIG->site_place, '',$article['article_title']);
			$body = str_replace('{KEYWORD}', '', $body);
			
			$content['heading'] = $CONFIG->site_title;
			
			$content['body'] = '
				<h2>'.$content['heading'].' – '.$CONFIG->site_tel.'</h2>
				<p>If you are looking for '.$CONFIG->site_title.' we can assist with the following services:</p>'.
				$body.
				'<p>We are the best '.$shorttitle.' company in '.$CONFIG->site_place.
					' so give us a call at: '.$CONFIG->site_tel.' today!</p>';
		}
	}
		
	if($PAGE['index']=='about-us') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "about"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "About us";
			$content['body'] = $article['page_content'];
		}
	}
		
	if($PAGE['index']=='services') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "services"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "Services";
			$content['body'] = $article['page_content'];
		}
	}
		
	if($PAGE['index']=='contact-us') {	
		$content['heading'] = "Contact Us";
		$content['body'] = '
			<h2>Contact us today for a free quote!</h2>
			<p>
				Please use our contact form to send us your enquiry. <br>
				Alternatively you can also contact us directly:
			</p>
			<p>
				<strong>Telephone: </strong>
				'.$CONFIG->site_tel.'
			</p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7182354.058309485!2d24.672226849999998!3d-28.4792811!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1c34a689d9ee1251%3A0xe85d630c1fa4e8a0!2sSouth+Africa!5e0!3m2!1sen!2sza!4v1435702515289" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		';
	}
		
	if($PAGE['index']=='advertise') {	
		$content['heading'] = "Advertise with us";
		$content['body'] = '
			<p>
				We connect you with clients requesting your services in your area. <br>
				For more information - fill in the query form below or call the following number.
			</p>
			<p>
				<strong>Telephone: </strong>
				'.$CONFIG->site_tel.'
			</p>
		';
	}
			
	$content['body'] .= "<h3>Areas that we operate in:</h3>";		
	$content['body'] .= implode(', ', $article_areas);		
		
	if($PAGE['index']=='areas') {
		$qry = 'SELECT * FROM `'.EXT.'pages` WHERE `page_type` = "areas"';
		$article_rs = $DB->query($qry);
		if($article_rs->num_rows > 0) {
			$article = $article_rs->fetch_assoc();
			
			$content['heading'] = "Areas that we service in ".$CONFIG->site_place;
			$content['body'] = "
				<h3>Some of the main areas that we service include:</h3>
				<ul>
			";
			// Get the areas
			$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
			$areas_rs = $DB->query($qry);
			if($areas_rs->num_rows > 0) {
				
				while($area = $areas_rs->fetch_assoc()) {
					$content['body'] .= '
						<li class="menu-item menu-item-type-post_type menu-item-object-page">
							'.$area['name'].'
						</li>';	
				}
					
			}
			$content['body'] .= "</ul>";
			
			$content['body'] .= "
				<h3>We also extend our ".str_replace($CONFIG->site_place, '', $CONFIG->site_title)." services to some of these other areas:</h3>
			";
			// Get the areas
			$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 0 ORDER BY `name` ASC';
			$areas_rs = $DB->query($qry);
			if($areas_rs->num_rows > 0) {
				
				while($area = $areas_rs->fetch_assoc()) {
					$content['body'] .= ' '.$area['name'].' ';	
				}
					
			}
			
		}
	}
	
}

?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo $meta['seo_title']; ?></title>
<link rel="stylesheet"  href="<?php echo ROOT; ?>/resources/bootstrap/css/bootstrap.min.css?ver=4.1.5" type="text/css" media="all" />
<link rel="stylesheet"  href="<?php echo ROOT; ?>/resources/glyphicons/css/bootstrap-glyphicons.css?ver=4.1.5" type="text/css" media="all" />
<link rel="stylesheet"  href="<?php echo ROOT; ?>/css/nivo-slider.css?ver=4.1.5" type="text/css" media="all" />
<link rel="stylesheet" href="<?php echo ROOT; ?>/css/style.css" type="text/css">
<meta name="description" content="<?php echo $meta['seo_desc']; ?>"/>
<link rel="canonical" href="http://<?php echo $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo $meta['seo_title']; ?>" />
<meta property="og:description" content="<?php echo $meta['seo_desc']; ?>" />
<meta property="og:url" content="http://<?php echo $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>" />
<meta property="og:site_name" content="<?php echo $CONFIG->site_title; ?>" />
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <script src="js/respond.js"></script>
<![endif]-->
</head>

<body class="theme-<?php echo $CONFIG->theme; ?>">
	
<header id="masthead" class="site-header" role="banner">
	<div class="container">
		<div class="row">
			<div class="site-header-inner col-12">
				
				<div class="col-sm-6 col-lg-7">
					<div id="logo"><a href="<?php echo $CONFIG->livesite; ?>" title="<?php echo $CONFIG->site_title; ?>" rel="home"><img src="<?php echo ROOT; ?>/images/logo.jpg" /></a></div>
				</div>
				
				<div class="col-sm-6 col-lg-5">
					<div class="top">
					<div class="tel">
						<span><a class="wit" href="tel:<?php echo $CONFIG->site_tel; ?>"><?php echo $CONFIG->site_tel; ?></a></span>
						<?php if(strlen($CONFIG->site_tel2)>1) : ?>
						<p style="font-size:16px; margin:0; text-transform:uppercase">Alternative number: <?php echo $CONFIG->site_tel2; ?></p>
						<?php else : ?><br/>
						<?php endif; ?>
						CALL, SMS OR EMAIL!</div>
                    <span style="font-size:12px;"><?php echo $CONFIG->site_header; ?></span>
					</div>
				</div>
						
			</div>
		</div>
	</div><!-- .container -->
</header><!-- #masthead -->
		
<nav class="site-navigation">		
	<div class="container">
		<div class="row">
			<div class="site-navigation-inner col-12">
				<div class="navbar">
					 
					 <div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="<?php echo $CONFIG->livesite; ?>" title="<?php echo $CONFIG->site_title; ?>" rel="home"><?php echo $CONFIG->site_title; ?></a>
					  </div>
				    
					<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav" id="main-menu">
						
						<li class="menu-item menu-item-type-custom menu-item-object-custom <?php echo ($PAGE['index']=='home'?'current-menu-item current_page_item active':''); ?> menu-item-home"><a href="<?php echo ROOT; ?>">Home</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($PAGE['index']=='about-us'?'current-menu-item current_page_item active':''); ?>"><a href="<?php echo ROOT; ?>/about-us">About Us</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($PAGE['index']=='areas'?'current-menu-item current_page_item active':''); ?>"><a href="<?php echo ROOT; ?>/areas">Areas</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2364 <?php echo ($PAGE['index']=='services'?'current-menu-item current_page_item active':''); ?>" id="menu-item-2364"><a href="<?php echo ROOT; ?>/services">Services</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47 <?php echo ($PAGE['index']=='contact-us'?'current-menu-item current_page_item active':''); ?>" id="menu-item-47"><a href="<?php echo ROOT; ?>/contact-us">Contact Us</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($PAGE['index']=='advertise'?'current-menu-item current_page_item active':''); ?>"><a href="<?php echo ROOT; ?>/advertise">Advertise with us</a></li>
					</ul></div>
				
				</div><!-- .navbar -->
			</div>
		</div>
	</div><!-- .container -->
</nav><!-- .site-navigation -->

<div class="main-content">	

	<div class="showcase">		
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="slider-wrapper">			
						<div id="slider" class="nivoSlider">
						<?php
						$slidespath = 'images/slides/';
						if ($handle = opendir($slidespath)) {
							while (false !== ($entry = readdir($handle))) {
								if ($entry != "." && $entry != "..") {
									echo '<img src="'.ROOT.'/images/slides/'.$entry.'" />';
								}
							}
							closedir($handle);
						}
						?>
						</div>
					</div>
				</div>
				<div class="slider-sidebar col-md-4">
					<div class="top">
						<h3 class="widget-title">Request a quote now!</h3>
						<div class="textwidget">
							<?php require_once('contact.php'); ?>
						</div>
					</div>
				</div>
			</div>
		</div><!-- .container -->
	</div><!-- .showcase -->
	
	<div class="container">
		<div class="row">
			<div class="main-content-inner col-12 col-md-8">
				
					<header class="page-header">
						<h1 class="page-title"><?php echo $content['heading']; ?></h1>
					</header><!-- .entry-header -->
				
					<div class="entry-content">
						<?php echo $content['body']; ?>
                        <?php if($PAGE['index']=='advertise') : 
                        	require_once('advertise.php');
                        endif; ?>
					</div><!-- .entry-content -->

			</div><!-- close .*-inner (main-content or sidebar, depending if sidebar is used) -->
			<div class="sidebar col-12 col-md-4">

				<div class="sidebar-padder">
                    <div class="committed">
                    	<?php echo $CONFIG->disclaimer; ?>
                    </div>
					<aside class="widget widget_nav_menu" id="nav_menu-2">
                    
							<h3 class="widget-title">Services</h3>
							<div class="menu-sidebar-menu-container">
								<ul class="menu nav" id="menu-sidebar-menu">
									<?php 
							
									// Get the main articles
									$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC LIMIT 10';
									$article_rs = $DB->query($qry);
									if($article_rs->num_rows > 0) {
									
										while($article = $article_rs->fetch_assoc()) {
											echo '<li><a href="'.ROOT.'/'.$article['slug'].'">'.$article['article_title'].'</a></li>';	
										}
										
									}
									
									?>		
								</ul>
							</div>
					</aside>			
				</div><!-- close .sidebar-padder -->
			</div>
		</div><!-- close .row -->
	</div><!-- close .container -->
</div><!-- close .main-content -->

<footer id="colophon" class="site-footer" role="contentinfo">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-md-2">
				<h3 class="widget-title">Navigation</h3>
				<div class="menu-main-menu-container">
					<ul>
						<li><a href="<?php echo ROOT; ?>">Home</a></li>
						<li><a href="<?php echo ROOT; ?>/about-us">About Us</a></li>
						<li><a href="<?php echo ROOT; ?>/areas">Areas</a></li>
						<li><a href="<?php echo ROOT; ?>/services">Services</a></li>
						<li><a href="<?php echo ROOT; ?>/contact-us">Contact Us</a></li>
					</ul>
				</div>			
			</div>	
			<div class="col-sm-6 col-md-3">
				<h3 class="widget-title">Areas</h3>
				<div class="menu-main-menu-container">
					<?php 

						// Get the areas
						$qry = 'SELECT * FROM `'.EXT.'areas` WHERE `menu` = 1 ORDER BY `name` ASC';
						$areas_rs = $DB->query($qry);
						if($areas_rs->num_rows > 0) {
							
							while($area = $areas_rs->fetch_assoc()) {
								echo $area['name'].' ';	
							}
								
						}
					
					?>
				</div>
			</div>	
			<div class="col-sm-6 col-md-4">
				<h3 class="widget-title">Services</h3>	
                <div class="services-list">
				<?php 
						
					// Get the main articles
					$qry = 'SELECT * FROM `'.EXT.'articles` ORDER BY `id` ASC';
					$article_rs = $DB->query($qry);
					if($article_rs->num_rows > 0) {
					
						while($article = $article_rs->fetch_assoc()) {
							echo '<a href="'.ROOT.'/'.$article['slug'].'">'.$article['article_title'].'</a> ';	
						}
						
					}
				
				?>		
                </div>
			</div>	
			<div class="col-sm-6 col-md-3">
				<h3 class="widget-title">Social networks</h3>			
				<div class="textwidget"><ul>
					<li><a href="#">Facebook</a></li>
					<li><a href="#">Twitter</a></li>
					<li><a href="#">LinkedIn</a></li>
					</ul></div>
				</div>		
			<div style="clear:both"><p><br></p></div>
		</div>
		<div class="row">
			<div class="copyright col-12">
				&copy; <?php echo date('Y'); ?> <?php echo $CONFIG->site_title; ?> |
                <a href="<?php echo $CONFIG->livesite; ?>/sitemap_index.xml" target="_blank">Sitemap</a>  | 
				<a href="http://www.websiteterms.co.za/" target="_blank">Terms and conidtions</a>
			</div>	
		</div>
	</div><!-- close .container -->
</footer><!-- close #colophon -->


<script type='text/javascript' src='<?php echo ROOT; ?>/js/jquery.js?ver=1.11.1'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/js/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/js/jquery.validate.min.js'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/js/jquery.maskedinput.js'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/resources/bootstrap/js/bootstrap.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/js/bootstrap-wp.js?ver=4.1.5'></script>
<script type='text/javascript' src='<?php echo ROOT; ?>/js/jquery.nivo.slider.pack.js?ver=4.1.5'></script>
<script type="text/javascript">
jQuery(window).load(function() {
    jQuery('#slider').nivoSlider({
		effect: 'fade',
        directionNav: false, // Next & Prev navigation
        controlNav: true, // Next & Prev navigation
		controlNavThumbs: false, 
        pauseTime: 5000
    });
});
</script>	
<script type="text/javascript" language="javascript">
jQuery(document).ready(function($) {
	$("#contactTel").mask("999 999 9999");
	$('#contactForm').validate({
		rules: {
			name: "required",
			email: {
				required: true,
				email: true
			},
			tel: "required",
			area: "required",
			message: "required"
		},
		messages: {
			name: "Please enter your name",
			email: {
				required: "Please enter your email address",
				email: "Please enter a valid email address"
			},
			tel: "Please enter your telephone",
			area: "Please select your area",
			message: "Please enter your message"
		}
	});

});

</script>

</body>
</html>